#!/bin/bash -x

DOWNLOAD_LOCATION="https://github.com/hhoegelo/mosaik-releases/releases/latest/download"

amixer -c $(aplay -l | grep USB | cut -f2 -d ' ' | grep -o '[0-9]*') sset 'Master' 100%
amixer -c $(aplay -l | grep UDJ6 | cut -f2 -d ' ' | grep -o '[0-9]*') sset 'PCM' 100%

# /usr/bin/wvkbd-mobintl&

function run_mosaik_loop() {
  while true; do
    sudo systemctl start mnt.mount
    sudo systemctl start mosaik-mount-prepare.service
    sudo systemctl start home-mosaik-Music-USB.mount
    sudo systemctl start home-mosaik-Music-FactoryLib.mount
    sudo systemctl start home-mosaik-Music-UserLib.mount
    sudo systemctl start home-mosaik-Music-Recordings.mount
    sudo systemctl start home-mosaik-Music-Bounces.mount

    /usr/bin/mosaik --alsa-out=hw:USB,0 --alsa-out=hw:UDJ6,0 --midi-ui hw:Micro,0,0 --root-dir /home/mosaik/Music
    exit_code=$?

    case $exit_code in
      0)
        exit 0
        ;;
      99) # see EXIT_UPDATE in CMakeLists.txt
        echo "Performing Update..."
        sudo apt-get update

        for P in app ab-update factory-init; do
          sudo apt-get install --only-upgrade --reinstall mosaik-$P
        done
        ;;
      *)
        echo "unexpected error: $exit_code"
        exit 0
        ;;
    esac

    sleep 1
  done
}

run_mosaik_loop&